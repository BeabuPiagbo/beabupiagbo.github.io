// let counts=setInterval(updated);
// let upto=10000;
// function updated(){
//     var count= document.getElementById("counter");
//     count.innerHTML=++upto;
//     if(upto===10207)
//     {
//         clearInterval(counts);
//     }
// }
